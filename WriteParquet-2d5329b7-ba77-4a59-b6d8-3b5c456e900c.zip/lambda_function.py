import json
import boto3
import pandas as pd
from s3fs.core import S3FileSystem

s3_client = boto3.client("s3")

def lambda_handler(event, context):
    bucketName = event['Records'][0]['s3']['bucket']['name']
    keyName = event['Records'][0]['s3']['object']['key']
    data = {0: {"data1": "value1"}}
    df = pd.DataFrame.from_dict(data, orient='index')
    write_pandas_parquet_to_s3(
        df, bucketName, keyName, keyName)


def write_pandas_parquet_to_s3(df, bucketName, keyName, fileName):
    # dummy dataframe
    table = pa.Table.from_pandas(df)
    pq.write_table(table, fileName)

    # upload to s3
    s3 = boto3.client("s3")
    BucketName = bucketName
    with open(fileName) as f:
       object_data = f.read()
       s3.put_object(Body=object_data, Bucket=BucketName, Key=keyName)